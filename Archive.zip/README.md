# Vietnamese Student Feedback Sentiment Analysis and Topics Classification Project
---
In this Project, we have used the Corpus name Vietnamese Student Feedback Corpus, which belongs to The UIT NLP Group and has more than 16000 feedback from Vietnamese students, to do the Sentiment Analysis task. The following table is the result of Precision, Recall, Accuracy, and F1-Score among SVM, MaxEnt and LSTM algorithms

### Uni-gram
|   |Precision   |Recall   |F1-Score   |Accuracy   |
|---|---|---|---|---|
|SVM   |   |   |   |   |
|MaxEnt   |   |   |   |   |


### Word2Vec
|   |Precision   |Recall   |F1-Score   |Accuracy   |
|---|---|---|---|---|
|SVM   |   |   |   |   |
|MaxEnt   |   |   |   |   |
|LSTM   |   |   |   |   |

---
## Wep Application
We have built A web application for Analyzing the Sentiment of Vietnamese Student's Feedback
![WebApp1](images/webapp2.png)
![WebApp1](images/webapp1.png)

---
## How to use?
#### Clone the project
```
$ git clone https://github.com/VuBacktracking/
```
#### Install required packages
```
$ pip install requirements.txt
```

#### Generate model (optional)

#### Now run
```
$ streamlit run app.py
```
