Download Vietnamese Stopwords in this following link:
---
https://github.com/stopwords/vietnamese-stopwords/blob/master/vietnamese-stopwords-dash.txt